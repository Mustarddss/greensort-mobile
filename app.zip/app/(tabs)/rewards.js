import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ActivityIndicator, Alert, KeyboardAvoidingView, Platform, TouchableWithoutFeedback, Keyboard, StatusBar } from 'react-native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { useRouter, useLocalSearchParams } from 'expo-router'; 
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../lib/supabase'; 
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';

const getSafeShadow = () => Platform.select({ 
    ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4 }, 
    android: { elevation: 3 } 
});

const OPENAI_API_KEY = process.env.EXPO_PUBLIC_OPENAI_API_KEY;

export default function Rewards() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();
  
  const [wasteType, setWasteType] = useState(params.wasteType || params.itemName || params.scannedWaste || '');
  const [quantity, setQuantity] = useState('1');
  const [unit, setUnit] = useState('kg'); 
  const [showUnitDropdown, setShowUnitDropdown] = useState(false);

  const [isClean, setIsClean] = useState(false);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]); 
  
  const [aiResultText, setAiResultText] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  useEffect(() => {
      if (params.wasteType || params.itemName || params.scannedWaste) {
          setWasteType(params.wasteType || params.itemName || params.scannedWaste || '');
      }
  }, [params.wasteType, params.itemName, params.scannedWaste]);

  const handleToggleClean = () => {
      const newValue = !isClean;
      setIsClean(newValue);
      if (!newValue) {
          setHasSearched(false);
          setResults([]);
          setAiResultText('');
      }
  };

  const isClaimedRewardLog = (claimedValue) => {
      const claimedText = String(claimedValue || '').trim().toLowerCase();

      return (
          claimedValue === true ||
          claimedValue === 1 ||
          claimedText === 'true' ||
          claimedText === 'claimed' ||
          (
              claimedText.length > 0 &&
              claimedText !== 'banked' &&
              !claimedText.includes('added to balance')
          )
      );
  };

  const isSameRewardName = (logReward, rewardName) => {
      const logText = String(logReward || '').toLowerCase();
      const rewardText = String(rewardName || '').toLowerCase();

      if (!logText || !rewardText) return false;

      return (
          logText.includes(rewardText) ||
          rewardText.includes(logText.replace('claimed:', '').trim())
      );
  };

  const handleSearch = async () => {
    if (!isClean) {
        return Alert.alert("Wait!", "Please confirm that your waste is clean and dry before searching.");
    }

    const finalWaste = wasteType.trim();

    if (!finalWaste) {
        Alert.alert("Missing Info", "Please enter a waste type to search.");
        return;
    }

    try {
        const gpsEnabled = await Location.hasServicesEnabledAsync();
        if (!gpsEnabled) {
            Alert.alert(
                "GPS is Off",
                "Please turn on your Location Services (GPS) so GreenSort AI can find the closest centers near you.",
                [{ text: "OK" }]
            );
        }
    } catch (e) {
        console.log("GPS check failed", e);
    }

    if (finalWaste.toLowerCase().includes("no detectable waste") || finalWaste.toLowerCase() === "none") {
        setHasSearched(true);
        setResults([]);
        setAiResultText("Please enter a valid waste item or recyclable material so I can find the right drop-off centers for you.");
        return;
    }
    
    setLoading(true);
    setHasSearched(true);
    setAiResultText(''); 
    Keyboard.dismiss();
    setShowUnitDropdown(false);

    try {
        const { data: { user } } = await supabase.auth.getUser();

        // 🟢 FIXED: Fetch lahat kahit false para alam natin kung sino ang out of stock
        const { data: rewardsData, error: rewardsError } = await supabase
            .from('rewards_inventory')
            .select('*')
            .ilike('condition', `%${finalWaste}%`);

        if (rewardsError) throw rewardsError;

        const { data: userLogs } = await supabase
            .from('surrender_logs')
            .select('*')
            .eq('resident_email', user?.email);

        const computedResults = [];
        const inputQty = parseFloat(quantity) || 1;

        for (const reward of rewardsData) {
            const { data: centerData } = await supabase
                .from('dropoff_applications')
                .select('*') 
                .eq('user_email', reward.user_email)
                .single();

            if (centerData) {
                const match = reward.condition.match(/(\d+)/);
                const baseRate = match ? parseFloat(match[1]) : 1;
                const rewardMultiplier = Math.floor(inputQty / baseRate);
                const isSufficient = rewardMultiplier >= 1;

                // 🟢 CLAIMED CHECK:
                // 1. If center marked reward as unavailable/out of stock.
                // 2. If current user already claimed a reward from this same center.
                // This fixes the issue where the card still shows as available after claiming.
                const userAlreadyClaimedThisReward = (userLogs || []).some(log => {
                    const logCollector = String(log.collector_email || '').toLowerCase();
                    const rewardCollector = String(reward.user_email || '').toLowerCase();

                    const sameCenter = logCollector === rewardCollector;
                    const rewardWasClaimed = isClaimedRewardLog(log.reward_claimed);
                    const sameReward = isSameRewardName(log.reward_claimed, reward.name);

                    return sameCenter && rewardWasClaimed && sameReward;
                });

                const isAlreadyClaimed =
                    !reward.is_available ||
                    Number(reward.stock_quantity || 0) <= 0 ||
                    userAlreadyClaimedThisReward;

                let cleanRewardName = reward.name;
                const doubleMatch = cleanRewardName.match(/^(\d+\s*(?:kg|pcs))\s+\1\s+(.*)/i);
                if (doubleMatch) {
                    cleanRewardName = `${doubleMatch[1]} ${doubleMatch[2]}`;
                }

                let totalRewardToGet = (isSufficient && rewardMultiplier > 1) 
                    ? `${rewardMultiplier}x ${cleanRewardName}` 
                    : cleanRewardName;
                
                let getExplanation = `For ${baseRate}${unit} clean ${finalWaste}`;

                let bringRequiredAmount = isSufficient 
                    ? `${inputQty} ${unit === 'kg' ? 'kilograms' : 'pieces'}` 
                    : `${baseRate} ${unit === 'kg' ? 'kilograms' : 'pieces'} minimum`;

                computedResults.push({
                    id: reward.id,
                    name: centerData.program_name || `Brgy. ${centerData.barangay}`,
                    address: centerData.exact_location || `${centerData.city}, ${centerData.region}`,
                    schedule: `${centerData.operating_days}: ${centerData.operating_hours}`,
                    contact: centerData.contact_number,
                    accepted: [reward.condition.replace(/[\d]+(kg|pcs)\s+/i, '')], 
                    
                    youBringItem: finalWaste,
                    bringRequiredAmount: bringRequiredAmount,
                    userHasAmount: `${inputQty}${unit}`, 
                    
                    youGetItem: totalRewardToGet, 
                    youGetReason: getExplanation, 
                    isSufficient: isSufficient,

                    baseRate: baseRate,
                    rewardUnit: cleanRewardName, 
                    subText: reward.description,
                    checklist: reward.checklist || '',
                    imageUrl: reward.image_url,
                    wasteImageUrl: reward.waste_image_url,
                    rewardInventoryId: reward.id,
                    stockQuantity: Number(reward.stock_quantity || 0),
                    isAvailable: !!reward.is_available,
                    isClaimed: isAlreadyClaimed,
                    searchedWasteType: finalWaste,
                    centerEmail: reward.user_email,
                    latitude: centerData.latitude,
                    longitude: centerData.longitude
                });
            }
        }
        setResults(computedResults);

        setIsAiLoading(true);
        let userLocation = "Cavite or Metro Manila"; 

        try {
            let { status } = await Location.requestForegroundPermissionsAsync();
            if (status === 'granted') {
                let location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }).catch(() => null);
                if (location) {
                    let geocode = await Location.reverseGeocodeAsync({
                        latitude: location.coords.latitude,
                        longitude: location.coords.longitude
                    });
                    if (geocode.length > 0) {
                        const address = geocode[0];
                        userLocation = [address.city || address.subregion, address.region].filter(Boolean).join(', ');
                    }
                }
            }
        } catch (locError) {
            console.log("Location retrieval skipped or failed.");
        }

        const aiPrompt = `The user wants to recycle or dispose of the following item: "${finalWaste}".
        They are currently located in or near: ${userLocation}, Philippines.
        
        CRITICAL RULE 1: First, determine if "${finalWaste}" is an actual physical waste item, recyclable material, or e-waste. 
        If it is NOT a valid waste item (e.g., a person, an abstract concept, random letters, or gibberish), DO NOT provide locations. Instead, reply EXACTLY with this sentence and nothing else: "Please enter a valid waste item or recyclable material so I can find the right drop-off centers for you."

        CRITICAL RULE 2: If it IS a valid waste item, provide a list of EXACT STORE NAMES, NGOs, OR SPECIFIC BUSINESSES near their location that accept this type of waste.
        DO NOT give generic answers like "local junk shops". Give real organization names (e.g., "SM Cares Trash to Cash", "The Plastic Flamingo", "IKEA Pasay", etc.).
        
        Format the response exactly like this:
        Exact places to check near ${userLocation}:
        - [Specific Store/NGO Name 1] - [Short description of what they accept]
        - [Specific Store/NGO Name 2] - [Short description of what they accept]
        - [Specific Store/NGO Name 3] - [Short description of what they accept]

        Tip: [Add a short, helpful tip about preparing this specific waste.]
         
        Keep it brief and conversational.
        Do NOT use markdown asterisks (**) for bolding.`;

        try {
            const aiRes = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${OPENAI_API_KEY}` },
                body: JSON.stringify({ 
                    model: 'gpt-5.4', 
                    messages: [{ role: 'user', content: aiPrompt }], 
                    temperature: 0.5, 
                    max_completion_tokens: 250 
                })
            });
            const aiData = await aiRes.json();
            if (aiData.choices && aiData.choices.length > 0) {
                setAiResultText(aiData.choices[0].message.content);
            }
        } catch (aiError) {
            console.log("AI Search Error:", aiError);
            setAiResultText("Sorry, GreenSort AI couldn't connect right now to search for recommendations. Please try again later.");
        } finally {
            setIsAiLoading(false);
        }

    } catch (error) {
        Alert.alert("Search Error", error.message);
    } finally {
        setLoading(false);
    }
  };

  // 🟢 REAL-TIME LISTENER PARA SA OUT OF STOCK / AVAILABLE + USER CLAIM UPDATES
  useEffect(() => {
      const uniqueId = Date.now();

      const inventoryChannel = supabase
          .channel(`realtime-inventory-${uniqueId}`)
          .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'rewards_inventory' }, (payload) => {
              setResults(currentResults =>
                  currentResults.map(loc => {
                      if (loc.id === payload.new.id) {
                          return {
                              ...loc,
                              stockQuantity: Number(payload.new.stock_quantity || 0),
                              isAvailable: !!payload.new.is_available,
                              isClaimed: loc.isClaimed || !payload.new.is_available || Number(payload.new.stock_quantity || 0) <= 0
                          };
                      }
                      return loc;
                  })
              );
          });

      inventoryChannel.subscribe();

      const surrenderChannel = supabase
          .channel(`realtime-user-surrender-claims-${uniqueId}`)
          .on('postgres_changes', { event: '*', schema: 'public', table: 'surrender_logs' }, async (payload) => {
              const { data: { user } } = await supabase.auth.getUser();
              const row = payload.new || payload.old;

              if (!user?.email || !row) return;
              if (String(row.resident_email || '').toLowerCase() !== String(user.email || '').toLowerCase()) return;

              const isRewardClaimed = isClaimedRewardLog(row.reward_claimed);

              if (!isRewardClaimed) return;

              setResults(currentResults =>
                  currentResults.map(loc => {
                      const sameCollector =
                          String(loc.centerEmail || '').toLowerCase() === String(row.collector_email || '').toLowerCase();
                      const sameReward = isSameRewardName(row.reward_claimed, loc.rewardUnit || loc.youGetItem);

                      return sameCollector && sameReward ? { ...loc, isClaimed: true, isAvailable: false } : loc;
                  })
              );
          });

      surrenderChannel.subscribe();

      return () => {
          supabase.removeChannel(inventoryChannel);
          supabase.removeChannel(surrenderChannel);
      };
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: '#F5F7FA' }}>
        <StatusBar barStyle="light-content" backgroundColor="#007C00" translucent={true} />
        
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={{flex: 1}}>
            <View style={[styles.header, { paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight || 24) + 15 : Math.max(insets.top, 20) + 15, paddingBottom: 25 }]}>
                <View style={styles.headerRow}>
                    <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                        <Ionicons name="arrow-back" size={24} color="white" />
                    </TouchableOpacity>
                    <View style={{alignItems: 'center'}}>
                        <Text style={styles.headerTitle}>Rewards Centers</Text>
                        <Text style={styles.headerSubtitle}>Find centers accepting your waste</Text>
                    </View>
                    <View style={{ width: 40 }} />
                </View>
            </View>

            <TouchableWithoutFeedback onPress={() => { Keyboard.dismiss(); setShowUnitDropdown(false); }}>
                <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
                    <View style={styles.body}>
                        
                        <View style={[styles.formCard, { zIndex: 10 }]}>
                            <Text style={styles.cardTitle}>Search Locations</Text>
                            
                            <Text style={styles.label}>Waste Type</Text>
                            <TextInput 
                                style={styles.input} 
                                placeholder="Type waste type (e.g. Computer Mouse, Plastic)" 
                                value={wasteType} 
                                onChangeText={setWasteType} 
                            />
                            
                            <Text style={styles.label}>Quantity</Text>
                            
                            <View style={styles.quantityRowContainer}>
                                <TextInput 
                                    style={[styles.input, { flex: 1, marginBottom: 0 }]} 
                                    placeholder="1" 
                                    keyboardType="numeric" 
                                    value={quantity} 
                                    onChangeText={setQuantity} 
                                />
                                
                                <View style={{ position: 'relative', width: 90, zIndex: 100 }}>
                                    <TouchableOpacity 
                                        style={[styles.input, styles.dropdownBtn]} 
                                        onPress={() => setShowUnitDropdown(!showUnitDropdown)}
                                        activeOpacity={0.8}
                                    >
                                        <Text style={styles.dropdownBtnText}>{unit}</Text>
                                        <Ionicons name="chevron-down" size={16} color="#666" />
                                    </TouchableOpacity>

                                    {showUnitDropdown && (
                                        <View style={styles.dropdownMenu}>
                                            <TouchableOpacity style={styles.dropdownMenuItem} onPress={() => { setUnit('kg'); setShowUnitDropdown(false); }}>
                                                <Text style={[styles.dropdownMenuText, unit === 'kg' && {color: '#007C00', fontWeight: 'bold'}]}>kg</Text>
                                            </TouchableOpacity>
                                            <TouchableOpacity style={[styles.dropdownMenuItem, { borderBottomWidth: 0 }]} onPress={() => { setUnit('pcs'); setShowUnitDropdown(false); }}>
                                                <Text style={[styles.dropdownMenuText, unit === 'pcs' && {color: '#007C00', fontWeight: 'bold'}]}>pcs</Text>
                                            </TouchableOpacity>
                                        </View>
                                    )}
                                </View>
                            </View>

                            <TouchableOpacity style={[styles.checkboxContainer, isClean && styles.checkboxActive, { zIndex: 1 }]} onPress={handleToggleClean} activeOpacity={0.8}>
                                <View style={[styles.checkbox, isClean && {backgroundColor: '#007C00', borderColor: '#007C00'}]}>
                                    {isClean && <Ionicons name="checkmark" size={14} color="white" />}
                                </View>
                                <View style={{flex: 1}}>
                                    <Text style={styles.checkboxTitle}>My Waste is Clean and Dry</Text>
                                    <Text style={styles.checkboxSub}>Clean recyclables have higher value and are easier to process</Text>
                                </View>
                            </TouchableOpacity>

                            {!isClean && (
                                <Text style={{color: '#FF3B30', fontSize: 12, textAlign: 'center', marginBottom: 10, fontWeight: '600'}}>
                                    * You must confirm your waste is clean to search.
                                </Text>
                            )}

                            <TouchableOpacity 
                                style={[styles.searchBtn, { backgroundColor: isClean ? '#007C00' : '#ccc', zIndex: 1 }]} 
                                onPress={handleSearch} 
                                disabled={loading || !isClean}
                            >
                                {loading ? <ActivityIndicator color="white" /> : <><Ionicons name="search" size={18} color="white" style={{marginRight: 8}} /><Text style={styles.searchBtnText}>Search Centers</Text></>}
                            </TouchableOpacity>
                        </View>

                        {!hasSearched && (
                            <View style={styles.guidelinesCard}>
                                <Text style={styles.guideTitle}>HOW IT WORKS</Text>
                                
                                <View style={styles.guideStepRow}>
                                    <View style={styles.guideIconBg}><MaterialCommunityIcons name="magnify" size={20} color="#007C00" /></View>
                                    <View style={styles.guideTextContainer}>
                                        <Text style={styles.guideStepTitle}>1. Search Waste</Text>
                                        <Text style={styles.guideStepDesc}>Type the specific recyclable you want to dispose of (e.g., Plastic bottles, Cans, E-waste).</Text>
                                    </View>
                                </View>

                                <View style={styles.guideStepRow}>
                                    <View style={styles.guideIconBg}><MaterialCommunityIcons name="water-off" size={20} color="#007C00" /></View>
                                    <View style={styles.guideTextContainer}>
                                        <Text style={styles.guideStepTitle}>2. Clean & Dry</Text>
                                        <Text style={styles.guideStepDesc}>Ensure your recyclables are clean. Dirty items are often rejected or lose their exchange value.</Text>
                                    </View>
                                </View>

                                <View style={[styles.guideStepRow, {marginBottom: 0}]}>
                                    <View style={styles.guideIconBg}><MaterialCommunityIcons name="map-marker-check" size={20} color="#007C00" /></View>
                                    <View style={styles.guideTextContainer}>
                                        <Text style={styles.guideStepTitle}>3. Find Drop-off</Text>
                                        <Text style={styles.guideStepDesc}>Discover nearby partner centers that accept your items and check their estimated rewards.</Text>
                                    </View>
                                </View>
                            </View>
                        )}

                        {hasSearched && <Text style={[styles.sectionHeader, {color: '#1C1C1E'}]}>Available Locations</Text>}
                    
                        {hasSearched && results.length === 0 && !loading && <Text style={styles.noResults}>No registered app centers found for this waste.</Text>}

                        {results.map((loc) => (
                            <TouchableOpacity 
                                key={loc.id} 
                                style={[styles.tradeCard, loc.isClaimed && {opacity: 0.6}]} // 🟢 Added opacity kung out of stock
                                activeOpacity={0.9}
                                onPress={() => {
                                    if (loc.isClaimed) {
                                        Alert.alert("Already Claimed", "You already claimed this reward or it is currently unavailable.");
                                        return;
                                    }
                                    router.push({ pathname: '/location-details', params: { data: JSON.stringify(loc) } });
                                }}
                            >
                                {loc.isClaimed && <View style={styles.claimedBadge}><Text style={styles.claimedText}>ALREADY CLAIMED</Text></View>}
                                
                                <Text style={styles.locName}>{loc.name}</Text>
                                
                                <View style={styles.detailRow}>
                                    <Ionicons name="location-outline" size={16} color="#999" style={{marginRight: 4}} />
                                    <Text style={styles.detailText}>{loc.address} • {loc.schedule}</Text>
                                </View>

                                <View style={styles.materialsRow}>
                                    {loc.accepted.map((item, index) => (
                                        <View key={index} style={styles.materialTag}>
                                            <Text style={styles.materialText}>{item}</Text>
                                        </View>
                                    ))}
                                    <Text style={styles.distanceText}>Nearby</Text>
                                </View>

                                {(loc.latitude && loc.longitude) ? (
                                    <View style={styles.mapContainer}>
                                        <MapView
                                            style={styles.map}
                                            initialRegion={{
                                                latitude: parseFloat(loc.latitude),
                                                longitude: parseFloat(loc.longitude),
                                                latitudeDelta: 0.005, 
                                                longitudeDelta: 0.005,
                                            }}
                                            scrollEnabled={false} 
                                            zoomEnabled={false}
                                            pitchEnabled={false}
                                            rotateEnabled={false}
                                        >
                                            <Marker coordinate={{ latitude: parseFloat(loc.latitude), longitude: parseFloat(loc.longitude) }} />
                                        </MapView>
                                    </View>
                                ) : null}

                                <View style={styles.tradeBox}>
                                    <View style={styles.tradeCol}>
                                        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 2}}>
                                            <MaterialCommunityIcons name="cube-outline" size={16} color="#0056b3" style={{marginRight: 4}} />
                                            <Text style={styles.tradeSideTitle}>You Bring:</Text>
                                        </View>
                                        <Text style={styles.tradeMainValue} numberOfLines={1}>{loc.youBringItem}</Text>
                                        
                                        <Text style={[styles.tradeSubValue, {color: '#0056b3', fontWeight: '500'}]}>{loc.bringRequiredAmount}</Text>
                                        
                                        {!loc.isSufficient && (
                                            <View style={{marginTop: 8}}>
                                                <Text style={{color: '#D32F2F', fontWeight: 'bold', fontSize: 13}}>Not Enough</Text>
                                                <Text style={{color: '#D32F2F', fontStyle: 'italic', fontSize: 11, marginTop: 2, lineHeight: 14}}>
                                                    *Based on your search, you only have {loc.userHasAmount}.
                                                </Text>
                                            </View>
                                        )}
                                    </View>

                                    <View style={styles.tradeArrowWrapper}>
                                        <Ionicons name="arrow-forward" size={24} color="#00A86B" />
                                    </View>

                                    <View style={styles.tradeCol}>
                                        <View style={{flexDirection: 'row', alignItems: 'center', marginBottom: 2}}>
                                            <MaterialCommunityIcons name="gift-outline" size={16} color="#00A86B" style={{marginRight: 4}} />
                                            <Text style={[styles.tradeSideTitle, {color: '#00A86B'}]}>You Get:</Text>
                                        </View>
                                        
                                        <Text style={[styles.tradeMainValue, {color: '#00A86B', fontSize: 14}]} numberOfLines={2}>
                                            {loc.youGetItem}
                                        </Text>
                                        <Text style={[styles.tradeSubValue, {lineHeight: 14, marginTop: 2}]}>{loc.youGetReason}</Text>
                                    </View>
                                </View>

                                <TouchableOpacity 
                                    style={[styles.selectBtn, loc.isClaimed && styles.selectBtnDisabled]}
                                    onPress={() => {
                                        if (loc.isClaimed) {
                                            Alert.alert("Already Claimed", "This reward was already claimed. It will only open again once the center marks it as available.");
                                            return;
                                        }
                                        router.push({ pathname: '/location-details', params: { data: JSON.stringify(loc) } });
                                    }}
                                >
                                    <Text style={[styles.selectBtnText, loc.isClaimed && styles.selectBtnTextDisabled]}>
                                        {loc.isClaimed ? 'Already Claimed' : 'Select this location'}
                                    </Text>
                                </TouchableOpacity>
                            </TouchableOpacity>
                        ))}

                        {hasSearched && (
                            <View style={{ marginTop: 20 }}>
                                <Text style={[styles.sectionHeader, {color: '#007C00'}]}>Can’t find anything nearby?</Text>
                                <Text style={{color: '#666', fontSize: 13, marginBottom: 15, paddingHorizontal: 5}}>Check out our recommended places based on our research in your area.</Text>
                                
                                {isAiLoading ? (
                                    <View style={{padding: 20, alignItems: 'center'}}>
                                        <ActivityIndicator size="large" color="#007C00" />
                                        <Text style={{color: '#666', marginTop: 10, fontSize: 12}}>GreenSort is scanning locations near you...</Text>
                                    </View>
                                ) : aiResultText ? (
                                    <View style={styles.aiCard}>
                                        <View style={styles.aiHeader}>
                                            <Ionicons name="sparkles" size={18} color="#007C00" />
                                            <Text style={styles.aiLocName}>GreenSort Suggestions</Text>
                                        </View>
                                        <Text style={styles.aiDetails} selectable={true}>{aiResultText}</Text>
                                    </View>
                                ) : (
                                    !loading && <Text style={styles.noResults}>GreenSort could not find external locations at this moment.</Text>
                                )}
                            </View>
                        )}

                    </View>
                    <View style={{height: 100}} /> 
                </ScrollView>
            </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  scrollContainer: { flexGrow: 1 },
  header: { backgroundColor: '#007C00', paddingHorizontal: 20, borderBottomLeftRadius: 30, borderBottomRightRadius: 30, elevation: 5 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', width: '100%' },
  headerTitle: { color: 'white', fontSize: 22, fontWeight: 'bold' },
  headerSubtitle: { color: 'rgba(255,255,255,0.9)', fontSize: 13, marginTop: 2 },
  backButton: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 12 },
  body: { padding: 20 }, 
  
  guidelinesCard: { backgroundColor: '#E8F5E9', borderRadius: 16, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: '#C8E6C9' },
  guideTitle: { fontSize: 13, fontWeight: '900', color: '#2E7D32', marginBottom: 15, textAlign: 'center', letterSpacing: 1 },
  guideStepRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 15 },
  guideIconBg: { backgroundColor: 'white', width: 40, height: 40, borderRadius: 20, justifyContent: 'center', alignItems: 'center', elevation: 2, shadowColor: '#000', shadowOffset: {width: 0, height: 1}, shadowOpacity: 0.1, shadowRadius: 2, marginRight: 15 },
  guideTextContainer: { flex: 1, paddingTop: 2 },
  guideStepTitle: { fontSize: 14, fontWeight: 'bold', color: '#1C1C1E', marginBottom: 4 },
  guideStepDesc: { fontSize: 12, color: '#555', lineHeight: 18 },
  
  formCard: { backgroundColor: 'white', borderRadius: 20, padding: 20, marginBottom: 25, ...getSafeShadow() },
  cardTitle: { fontSize: 18, fontWeight: 'bold', color: '#333', marginBottom: 15 },
  label: { fontSize: 13, color: '#666', marginBottom: 6, fontWeight: '600', marginTop: 10 },
  input: { backgroundColor: '#F5F7FA', borderRadius: 10, padding: 14, marginBottom: 16, fontSize: 14, color: '#333', borderWidth: 1, borderColor: '#F0F0F0' },
  
  quantityRowContainer: { flexDirection: 'row', gap: 10, marginBottom: 16, zIndex: 10 },
  dropdownBtn: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 15, marginBottom: 0 },
  dropdownBtnText: { fontSize: 14, color: '#333', fontWeight: 'bold' },
  dropdownMenu: { position: 'absolute', top: 55, left: 0, right: 0, backgroundColor: 'white', borderRadius: 10, borderWidth: 1, borderColor: '#eee', elevation: 5, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, zIndex: 1000 },
  dropdownMenuItem: { paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: '#f0f0f0', alignItems: 'center' },
  dropdownMenuText: { fontSize: 14, color: '#333' },

  checkboxContainer: { flexDirection: 'row', backgroundColor: '#e7ffe0', padding: 12, borderRadius: 10, borderWidth: 1, borderColor: '#d1ffb2', marginBottom: 20, marginTop: 5 },
  checkboxActive: { backgroundColor: '#b2ffbe', borderColor: '#4dff65' },
  checkbox: { width: 20, height: 20, borderRadius: 4, borderWidth: 2, borderColor: '#007C00', marginRight: 10, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  checkboxTitle: { fontSize: 13, fontWeight: 'bold', color: '#333' },
  checkboxSub: { fontSize: 11, color: '#666', marginTop: 2, lineHeight: 14 },
  searchBtn: { backgroundColor: '#007C00', paddingVertical: 14, borderRadius: 25, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', elevation: 2 },
  searchBtnText: { fontWeight: 'bold', color: 'white', fontSize: 14 },
  sectionHeader: { fontSize: 16, fontWeight: '900', marginBottom: 10, letterSpacing: 0.5, paddingHorizontal: 5 },
  noResults: { textAlign: 'center', color: '#999', marginTop: 10, marginBottom: 20, fontSize: 13 },
  
  tradeCard: { backgroundColor: 'white', borderRadius: 20, padding: 20, marginBottom: 20, ...getSafeShadow() },
  locName: { fontSize: 18, fontWeight: 'bold', color: '#1C1C1E', marginBottom: 6 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  detailText: { fontSize: 12, color: '#666', flex: 1 },
  materialsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 15 },
  
  mapContainer: { width: '100%', height: 130, borderRadius: 12, overflow: 'hidden', marginBottom: 15, borderWidth: 1, borderColor: '#E5E5EA' },
  map: { width: '100%', height: '100%' },
  
  materialTag: { backgroundColor: '#E8F5E9', paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, borderWidth: 1, borderColor: '#A5D6A7' },
  materialText: { fontSize: 11, color: '#00A86B', fontWeight: 'bold' },
  distanceText: { marginLeft: 'auto', fontSize: 12, color: '#999', alignSelf: 'center', fontWeight: '500' },
  
  tradeBox: { flexDirection: 'row', backgroundColor: '#F0FFF4', borderRadius: 12, padding: 15, borderWidth: 1, borderColor: '#A5D6A7', marginBottom: 20, alignItems: 'flex-start' },
  tradeCol: { flex: 1 },
  tradeSideTitle: { fontSize: 11, color: '#0056b3', fontWeight: '600' },
  tradeMainValue: { fontSize: 15, fontWeight: 'bold', color: '#1C1C1E', marginBottom: 4, textTransform: 'capitalize' },
  tradeSubValue: { fontSize: 11, color: '#666' },
  tradeArrowWrapper: { paddingHorizontal: 10, justifyContent: 'center', alignItems: 'center', alignSelf: 'center' },

  selectBtn: { borderWidth: 1.5, borderColor: '#00A86B', paddingVertical: 12, borderRadius: 25, alignItems: 'center' },
  selectBtnDisabled: { borderColor: '#9E9E9E', backgroundColor: '#F5F5F5' },
  selectBtnText: { color: '#00A86B', fontWeight: 'bold', fontSize: 14 },
  selectBtnTextDisabled: { color: '#757575' },
  
  claimedBadge: { position: 'absolute', top: 15, right: 15, backgroundColor: '#9E9E9E', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 5, zIndex: 5 },
  claimedText: { color: 'white', fontSize: 10, fontWeight: 'bold', letterSpacing: 1 },
  aiCard: { backgroundColor: '#F1F8E9', borderRadius: 15, padding: 18, marginBottom: 15, borderWidth: 1, borderColor: '#C8E6C9', ...getSafeShadow() },
  aiHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  aiLocName: { fontSize: 16, fontWeight: 'bold', color: '#007C00', marginLeft: 8 },
  aiDetails: { fontSize: 14, color: '#333', lineHeight: 22 }
});